<?php
// Temperatura en Celsius
$celsius = rand(1, 100);

// Fórmula de conversión
$fahrenheit = ($celsius * 9 / 5) + 32;

// Mostrar el resultado
echo "$celsius °C equivale a $fahrenheit °F <br>";
?>
