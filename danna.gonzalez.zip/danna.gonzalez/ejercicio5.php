<?php

$nombre = ("Danna Ximena");

$edad = ("17 ");

// Mostrar el mensaje de bienvenida
echo "¡Bienvenido, " . $nombre . "! Tienes " . $edad . " años.";
?>