<?php
$numero = ("-13");

if ($numero > 0) {
    echo "El número " . $numero . " es positivo.";
} elseif ($numero < 0) {
    echo "El número " . $numero . " es negativo.";
} else {
    echo "El número es cero.";
}
?>