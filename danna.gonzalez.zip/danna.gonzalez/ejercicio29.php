<?php
// Lista de números predefinidos
$numeros = [10, 2, 15, 8, 3];

// Ordenar los números
sort($numeros);

// Mostrar los números ordenados
echo "Lista ordenada: " . implode(", ", $numeros);
?>