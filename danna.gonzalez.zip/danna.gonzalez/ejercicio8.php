<?php
$base = ("18");

$altura = ("32");

$area = ($base * $altura) / 2;

echo "El área del triángulo es: " . $area;
?>