<?php

$numero = 6;  

for ($contador = 1; $contador <= 10; $contador++) {
    echo "$numero x $contador = " . ($numero * $contador) . "<br>";
}
?>