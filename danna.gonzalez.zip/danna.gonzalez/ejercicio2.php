<?php
$edad = 17; // Reemplaza 30 con tu edad real
echo "Tengo " . $edad . " años.";
?>