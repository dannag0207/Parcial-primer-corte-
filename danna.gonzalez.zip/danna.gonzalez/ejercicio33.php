<?php

$horas = 6; 


$minutos = $horas * 60; 
$segundos = $horas * 3600; 


echo "$horas horas son $minutos minutos o $segundos segundos.";
?>