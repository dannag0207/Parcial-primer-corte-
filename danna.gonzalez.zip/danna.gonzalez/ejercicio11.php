<?php
$calificacion = 23; 
$umbralAprobacion = 55;

if ($calificacion >= $umbralAprobacion) {
    echo "La calificación es aprobatoria.";
} else {
    echo "La calificación es reprobatoria.";
}
?>