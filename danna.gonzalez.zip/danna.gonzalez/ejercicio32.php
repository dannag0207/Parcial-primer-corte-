<?php

$lanzamiento = rand(1, 6);  


echo "El resultado del lanzamiento del dado es: $lanzamiento";
?>