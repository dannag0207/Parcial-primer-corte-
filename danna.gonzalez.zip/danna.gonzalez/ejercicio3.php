<?php
$numero1 = 6;
$numero2 = 7;
$suma = $numero1 + $numero2;
echo "La suma de " . $numero1 . " y " . $numero2 . " es: " . $suma;
?>