<?php
// Número de ejemplo
$numero = rand(1, 100);


if ($numero % 2 == 0) {
    echo "El número $numero es par. <br>";
} else {
    echo "El número $numero es impar. <br>";
}
?>
