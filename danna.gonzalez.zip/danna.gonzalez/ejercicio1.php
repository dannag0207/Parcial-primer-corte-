<?php
$nombre = "Danna Gonzalez"; 
echo "Mi nombre es: " . $nombre;
?>