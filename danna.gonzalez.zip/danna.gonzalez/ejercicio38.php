<?php

function sumar($numero1, $numero2) {
    return $numero1 + $numero2;
}


$num1 = 6;
$num2 = 12;
$resultado = sumar($num1, $num2);


echo "La suma de $num1 y $num2 es: $resultado";
?>