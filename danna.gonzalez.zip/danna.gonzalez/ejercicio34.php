<?php

$edad = 19;  


$año_actual = date("Y");


$año_nacimiento = $año_actual - $edad;


echo "Si tienes $edad años, naciste en el año $año_nacimiento.";
?>