<?php
$numero1 = ("8");

$numero2 = ("9");

$resultado = $numero1 * $numero2;

echo "El resultado de la multiplicación es: " . $resultado;
?>