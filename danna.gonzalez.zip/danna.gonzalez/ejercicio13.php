<?php
$nombre = ("Danna");
echo "¡Hola, " . $nombre . "! Bienvenido ¿Como podemos ayudarte?.";
?>