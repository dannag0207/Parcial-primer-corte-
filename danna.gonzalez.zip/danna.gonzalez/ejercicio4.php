<?php
$edad = 30;
if ($edad >= 18) {
    echo "La persona es mayor de edad.";
} else {
    echo "La persona es menor de edad.";
}
?>