<?php
// Definir una cadena en minúsculas
$texto = "hola.";


$textoMayusculas = strtoupper($texto);

echo "Texto original: $texto <br>";
echo "Texto en mayúsculas: $textoMayusculas";
?>
