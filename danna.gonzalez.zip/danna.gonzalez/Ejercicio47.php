<?php
while (true) {
    echo "Hora actual: " . date("H:i:s") . "\r"; // \r para sobrescribir en la misma línea
    sleep(1); // Espera 1 segundo
}
?>
